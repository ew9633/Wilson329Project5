// Elhanan Wilson

import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;
import java.net.Socket;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class AccountListScene extends SceneBasic {

	private OutputTable output = new OutputTable("Username", "Account"); 

	public AccountListScene() {
		super("Account List");
		GridPane gridPane = new GridPane(); 
		gridPane.setPadding(new Insets(10, 10, 10, 10));
		gridPane.setVgap(5);
		gridPane.setHgap(5);
		gridPane.setAlignment(Pos.CENTER);
		root.getChildren().addAll(gridPane);
		
	}

	public void getAccountList() {
		try {
			Socket connection = SceneManager.getSocket(); 
			PrintWriter outgoing; 
			outgoing = new PrintWriter(connection.getOutputStream());
			System.out.println("Sending... ACCOUNT_LIST");
			outgoing.println("SEND_ACCOUNT_LIST");
			outgoing.flush();

			BufferedReader incoming = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			System.out.println("Waiting for account list...");
			String username = incoming.readLine();
			while (!username.equals("DONE")) {
				String type = incoming.readLine();
				System.out.println(type);
				output.addRow(username, type);
				System.out.println("Received " + username + ", " + type); 
				username = incoming.readLine();
			}
			output.clearData(); 
			root.getChildren().addAll(output); 
			addButton("Admin Menu", e -> SceneManager.setScene(SceneManager.SceneType.admin)); 
			addButton("Logout", e -> logout()); 
		} catch (Exception e) {
			System.out.println("Error:  " + e);
		}
	}
}
