// Elhanan Wilson

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;

public class OutputTable extends GridPane {

	private int row = 1; 
	private final int FONT_SIZE = 20;

	public OutputTable(String... headers) {

        super.setAlignment(Pos.CENTER);
		for (int i = 0; i < headers.length; i++) {
			Label label = new Label(headers[i]);
			label.setFont(new Font(FONT_SIZE));
			super.add(label, i, 0);
		}
	}

	public void addRow(String... text) {
		for (int i = 0; i < text.length; i++) {
			Label label = new Label(text[i]);
			label.setFont(new Font(FONT_SIZE));
			super.add(label, i, row); 
		}
		row++;
	}
	
	public void clearData() {
		row = 1;
	}
}
