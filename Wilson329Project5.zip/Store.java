// Elhanan Wilson

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

public class Store extends Application {

	private SceneManager sceneManager; 

	private Socket connection; 

	public Store() {
		sceneManager = new SceneManager();
	}

	public static void main(String[] args) {
		launch(args);
	}

	public void start(Stage stage) {
		Store store = new Store();

		store.sceneManager.setStage(stage);
		SceneManager.setScene(SceneManager.SceneType.login);
		stage.show();

	}

	public void stop() {
		System.out.println("Sending quit singal");
		try {
			PrintWriter outgoing = new PrintWriter(connection.getOutputStream());
			outgoing.println("QUIT");
			outgoing.flush();
			connection.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
