// Elhanan Wilson

import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane; 
import javafx.geometry.Insets;

import java.net.Socket;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.*;
import javafx.scene.paint.Color;

public class PlaceOrderScene extends SceneBasic {
	
	private GridPane gridPane = new GridPane();
	private UserInput stock = new UserInput("Stock #: "); 
	private UserInput quantity = new UserInput("Quantity: ");
	private OutputTable output = new OutputTable("Stock #", "Description");

	public PlaceOrderScene() {
        super("Ordering"); 
        gridPane.setPadding(new Insets(10, 10, 10, 10)); 
        gridPane.setVgap(5); 
        gridPane.setHgap(5);  
        gridPane.setAlignment(Pos.CENTER);
		root.getChildren().addAll(output); 
        root.getChildren().addAll(gridPane);
        

       
	}
	
	public void getInventory() {
		try {
			Socket connection = SceneManager.getSocket(); 
	    	PrintWriter outgoing;   
			outgoing = new PrintWriter( connection.getOutputStream() );
			System.out.println("Sending... INVENTORY");
			outgoing.println("INVENTORY");
			outgoing.flush();

	        BufferedReader incoming = new BufferedReader(new InputStreamReader(connection.getInputStream()));
	        System.out.println("Waiting for inventory...");
	        String stockNumber = incoming.readLine();
	        while (!stockNumber.equals("DONE")) {
		        String description = incoming.readLine();
	        	output.addRow(stockNumber, description); 
		        System.out.println("Received " + stockNumber + ", " + description); 
		        stockNumber = incoming.readLine();
	        }
	        output.clearData(); 
			gridPane.add(stock, 0, 0);
	        gridPane.add(quantity, 0, 1);
			addButton("Submit", e -> sendOrder()); 
	        addButton("Cancel", e -> SceneManager.setScene(SceneManager.SceneType.customer)); 
		}
        catch (Exception e) {
            System.out.println("Error:  " + e);
        }
	}
	
	public void sendOrder() {
		String stockNumber = stock.getText();
		String quantitys = quantity.getText();
        try {
			Socket connection = SceneManager.getSocket(); 
        	PrintWriter outgoing;   
			outgoing = new PrintWriter( connection.getOutputStream() );
			outgoing.println("ORDER");
			outgoing.println(stockNumber);
			outgoing.println(quantitys);
			outgoing.flush();  
            System.out.println("Sent order info"); 
            SceneManager.setScene(SceneManager.SceneType.customer);
        }
        catch (Exception e) {
        	System.out.println("Error trying to connect to server.");
            System.out.println("Error:  " + e);
        }
	}
}

