// Elhanan Wilson

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;

public class StoreThread extends Thread {

	private Socket client;
	public HashMap<String, Account> accounts;
	public Account userAccount;
	private BufferedReader incoming;
	private PrintWriter outgoing;

	public StoreThread(Socket client) {
		this.client = client;
	}

	public void run() {
		accounts = AccountsReader.readFile("accounts.txt");
		try {
			incoming = new BufferedReader(new InputStreamReader(client.getInputStream()));
			outgoing = new PrintWriter(client.getOutputStream());
			boolean choice = false;
			while (!choice) {
				String lineFromServer = incoming.readLine();
				if (lineFromServer.equals("LOGIN")) {
					login(accounts, incoming, outgoing);
				} else if (lineFromServer.equals("SEND_ACCOUNT_LIST")) {
					sendAccountList(outgoing);
				} else if (lineFromServer.equals("SEND_PROFILE")) {
					sendProfile(outgoing);
				} else if (lineFromServer.equals("CHANGE_PASSWORD")) {
					changePassword(userAccount, incoming, outgoing);
				}  else if (lineFromServer.equals("INVENTORY")) {
					sendInventory(outgoing);
				} else if (lineFromServer.equals("VIEW_ORDERS")) {
					viewOrders(outgoing);
				} else if (lineFromServer.equals("QUIT")) {
					if (client == null) {
						choice = true;
					}
				}

			}

		} catch (Exception e) {
			System.out.println("Sorry, the server has shut down.");
			System.out.println("Error:  " + e);
			return;
		}

	}

	public synchronized void login(HashMap<String, Account> accounts, BufferedReader incoming, PrintWriter outgoing) {
		try {

			String username = incoming.readLine();
			System.out.println(username);
	
			String password = incoming.readLine(); 
			System.out.println(password);


			for (String id : accounts.keySet()) {
				Account account = accounts.get(id);
				if (username.equals(account.getUsername())) {
					if (password.equals(account.getPassword())) {
						userAccount = account;
						if (userAccount instanceof AdminAccount) {
							outgoing.println("ADMIN_SCENE"); 
							outgoing.flush();
							return;
						} else if (userAccount instanceof CustomerAccount) {
							outgoing.println("CUSTOMER_SCENE"); 
							outgoing.flush();
							return;
						}
					}
					outgoing.println("INVALID_PASSWORD"); 
					outgoing.flush();
					return;

				}

			}
			outgoing.println("INVALID_USERNAME"); 
			outgoing.flush();
		} catch (Exception e) {
			System.out.println("HERE");
			System.out.println("Error:  " + e);
		}

	}

	public void sendAccountList(PrintWriter outgoing) {
		for (String id: accounts.keySet()) {
			outgoing.println(accounts.get(id).getUsername());
			if (accounts.get(id) instanceof AdminAccount) {
				outgoing.println("Administrator");
			} else if (accounts.get(id) instanceof CustomerAccount) {
				outgoing.println("Customer");
			}
		}
		outgoing.println("DONE");
		outgoing.flush();

	}
	
	public void sendProfile(PrintWriter outgoing) {
		CustomerAccount customer = (CustomerAccount) userAccount;
		outgoing.println(customer.getProfile());
		outgoing.flush();
	}

	public synchronized void changePassword(Account userAccount, BufferedReader incoming, PrintWriter outgoing) {
		String wrongPassword = ""; 

		try {
			String curPassword = incoming.readLine();
			String newPassword = incoming.readLine(); 
			if (userAccount.verifyPassword(curPassword)) {
				userAccount.setPassword(newPassword);

				for (String id : accounts.keySet()) {
					if (userAccount.getUsername().equals(accounts.get(id).getUsername())) {
						accounts.put(id, userAccount);
					}
				}

			} else {
				wrongPassword = "WRONG_PASSWORD"; 
				outgoing.println(wrongPassword);
			}
		} catch (Exception e) {
			System.out.println("Error:  " + e);
		}
		
		try {
			PrintWriter print = new PrintWriter("accounts.txt");
			print.println("<ACCOUNTS>");
			for (String id : accounts.keySet()) {
				if (accounts.get(id) instanceof AdminAccount) {
					print.println("<ADMINISTRATOR>");
					print.println("<id>");
					print.println(accounts.get(id).getId());
					print.println("</id>");
					print.println("<username>");
					print.println(accounts.get(id).getUsername());
					print.println("</username>");
					print.println("<password>");
					print.println(accounts.get(id).getPassword());
					print.println("</password>");
					print.println("</ADMINISTRATOR");
				} else if (accounts.get(id) instanceof CustomerAccount) {
					CustomerAccount customer = (CustomerAccount) accounts.get(id);
					print.println("<CUSTOMER>");
					print.println("<id>");
					print.println(accounts.get(id).getId());
					print.println("</id>");
					print.println("<username>");
					print.println(accounts.get(id).getUsername());
					print.println("</username>");
					print.println("<password>");
					print.println(accounts.get(id).getPassword());
					print.println("</password>");
					print.println("<profile>");
					print.println(customer.getProfile());
					print.println("</profile>");
					print.println("</CUSTOMER>");
				}

			}
			print.println("</ACCOUNTS>");
			print.close();

		} catch (FileNotFoundException e) {
			System.out.println("Can't open file result.dat!");
			System.out.println("Error: " + e);
			return; 
		}

		if (wrongPassword.equals("WRONG_PASSWORD")) {
			outgoing.println(wrongPassword);
			outgoing.flush(); 
		} else if (userAccount instanceof AdminAccount) {
			outgoing.println("ADMIN_SCENE");
			outgoing.flush(); 
		} else if (userAccount instanceof CustomerAccount) {
			outgoing.println("CUSTOMER_SCENE");
			outgoing.flush(); 
		}
		outgoing.flush();
	}
	
	public synchronized void getOrder(BufferedReader incoming) {
		try {
            String stockNumber = incoming.readLine();
            String quantity = incoming.readLine();
            System.out.println("Received: " + stockNumber + ", " + quantity); 
    		
            String filename = "orders2.dat";
            OutputStream out = new FileOutputStream(filename, true);
            out.write(userAccount.getId());
            out.write(Integer.parseInt(stockNumber));
            out.write(Integer.parseInt(quantity));
            out.close();
            System.out.println("Updated orders file");
        }
        catch (Exception e){
            System.out.println("Error: " + e);
        }
	}

	public void sendInventory(PrintWriter outgoing) {
		HashMap<String, String> inventory = InventoryReader.readFile("inventory.txt");
    	System.out.println("Read inventory: " + inventory);
		for (String stockNumber : inventory.keySet()) {
	        outgoing.println(stockNumber);
			outgoing.println(inventory.get(stockNumber));
            System.out.println("Sending: " + stockNumber + ", " + inventory.get(stockNumber));
		}
        outgoing.println("DONE");
        System.out.println("done");
        outgoing.flush();
	}
	
	public void viewOrders(PrintWriter outgoing) {
		int stock;
		String description;
		int quantity;
		HashMap<String, String> inventory = InventoryReader.readFile("inventory.txt");
		InputStream source;
		try {
			source = new FileInputStream("orders2.dat"); 
			boolean a = true;
			int data = source.read();
			while (a == true) {
				if (data < 0) {
					a = false;
					outgoing.println("DONE");
					outgoing.flush();
					source.close();
				} else {
					data = source.read();
					stock = data; 
					outgoing.println(stock);
					System.out.println(stock);
					description = inventory.get(Integer.toString(stock)); 
					System.out.println(description);
					outgoing.println(description);
					data = source.read();
					quantity = data; 
					outgoing.println(quantity);
					System.out.println(quantity);
					data = source.read();
				
				}
			}
		} catch (IOException e) {
			System.out.println("Can't find file \"" + "orders.dat" + "\".");
			return;
		}

	}
}
