// Elhanan Wilson

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class SettingsScene extends SceneBasic {
	private UserInput host = new UserInput("Host:"); 
	private UserInput port = new UserInput("Port:"); 
	private ButtonBar bar = new ButtonBar(); 
	private Label errorMessage = new Label(); 
	private CustomerChat chat = new CustomerChat(); 


	public SettingsScene() {
		super("Connection Settings");
		bar.addButton("Apply", e -> apply(host.getText(), port.getText()));
		bar.addButton("Cancel", e -> cancel()); 
		bar.addButton("Chat", e -> chat.start(new Stage()));
		GridPane gridPane = new GridPane();
		gridPane.setMinSize(400, 200);
		gridPane.setPadding(new Insets(10, 10, 10, 10));
		gridPane.setVgap(5);
		gridPane.setHgap(5);
		gridPane.add(host, 0, 0);
		gridPane.add(port, 0, 1);
		gridPane.add(bar, 0, 2);
		errorMessage.setTextFill(Color.RED);
		gridPane.add(errorMessage, 1, 3);
		gridPane.setAlignment(Pos.TOP_CENTER);
		root.getChildren().addAll(gridPane);

	}

	public void apply(String hostNum, String portNum) {
		if (hostNum.equals("localhost") && portNum.equals("32007")) {
			try {
				SceneManager.setSocket(new Socket(hostNum, Integer.parseInt(portNum)));

			} catch (NumberFormatException e) {

				e.printStackTrace();
			} catch (UnknownHostException e) {

				e.printStackTrace();
			} catch (IOException e) {

				e.printStackTrace();
			}
			SceneManager.setScene(SceneManager.SceneType.login);
		} else
			errorMessage.setText("Port Number or Host Name Does Not Match");

	}

	public void cancel() {
		SceneManager.setScene(SceneManager.SceneType.login);

	}

	@Override
	public Scene getScene() {
		errorMessage.setText("");
		return super.getScene();
	}

}
