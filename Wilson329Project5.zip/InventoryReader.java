// Elhanan Wilson

import java.io.*;
import java.util.HashMap;
import java.util.Scanner;

public  class InventoryReader {
    public static HashMap<String, String> readFile(String filename) {
        Scanner data;    
        HashMap<String, String> inventory = new HashMap<>();

        try {  
            data = new Scanner(new File(filename));
        }
        catch (FileNotFoundException e) {
            System.out.println("Can't find file!");
            return inventory;  
        }

        String stockNumber = "";
        String description = "";
        while ( data.hasNextLine() ) {  
            String line = data.nextLine();
            if (line.equals("</PRODUCT>")) {
            	inventory.put(stockNumber, description);
            }
            else if (line.equals("<StockNumber>")) {
            	stockNumber = data.nextLine();
            	System.out.println(stockNumber);
            }
            else if (line.equals("<Description>")) {
            	description = data.nextLine();
            	System.out.println(description);
            }
        }

        System.out.println("Done!");

        data.close();
        System.out.println(inventory.get("45"));
        return inventory;  
    }  
} 