// Elhanan Wilson

import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class StoreServer {

	private static int LISTENING_PORT = 32007; 

	public static void main(String[] args) {
		try {
			ServerSocket listener = new ServerSocket(LISTENING_PORT); 
			System.out.println("Listening on port " + LISTENING_PORT);

			while (true) {
				Socket connection = listener.accept();
				System.out.println("Connection from " +  
	                    connection.getInetAddress().toString() );
				StoreThread thread = new StoreThread(connection);
				thread.start();
				System.out.println("A new thread has been started");
			}
		} catch (Exception e) {
			System.out.println("Sorry, the server has shut down.");
			System.out.println("Error:  " + e);
			return;
		}

	} 

}