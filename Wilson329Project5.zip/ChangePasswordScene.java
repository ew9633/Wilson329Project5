// Elhanan Wilson

import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javafx.scene.paint.Color;

public class ChangePasswordScene extends SceneBasic {

	private PasswordInput oldPass = new PasswordInput("Old Password:"); 
	private PasswordInput newPass = new PasswordInput("New Password:"); 
	private Label errorMessage = new Label(); 
	private GridPane gridPane = new GridPane(); 

	public ChangePasswordScene() {
		super("Change Password");
		errorMessage.setTextFill(Color.RED);
		gridPane.setMinSize(400, 100);
		gridPane.setPadding(new Insets(10, 10, 10, 10));
		gridPane.setVgap(5);
		gridPane.setHgap(5);
		gridPane.add(oldPass, 0, 0);
		gridPane.add(newPass, 0, 1);
		gridPane.setAlignment(Pos.TOP_CENTER);
		root.getChildren().addAll(gridPane);
		addButton("Change", e -> change()); 
	}

	private void change() {
		try {
			Socket connection = SceneManager.getSocket(); 
			PrintWriter outgoing; 
			outgoing = new PrintWriter(connection.getOutputStream());
			System.out.println("Sending... CHANGE_PASSWORD");
			outgoing.println("CHANGE_PASSWORD");
			outgoing.flush();

			String oldInput = oldPass.getText();
			String newInput = newPass.getText();
			outgoing.println(oldInput);
			outgoing.println(newInput);
			outgoing.flush();
			System.out.println("Sent password info"); 

			BufferedReader incoming = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			System.out.println("Waiting for result...");
			String reply = incoming.readLine();
			if (reply.equals("ADMIN_SCENE")) {
				errorMessage.setText("");
				SceneManager.setScene(SceneManager.SceneType.admin);
			} else if (reply.equals("CUSTOMER_SCENE")) {
				errorMessage.setText("");
				SceneManager.setScene(SceneManager.SceneType.customer);
			} else
				errorMessage.setText(reply);
		}

		catch (Exception e) {
			System.out.println("Error:  " + e);
		}
	}
}
