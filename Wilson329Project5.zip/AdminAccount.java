// Elhanan Wilson 

import java.util.ArrayList;

public class AdminAccount extends Account {

	private ArrayList<Account> accounts = new ArrayList<Account>(); 
	private String password; 
	private String username; 

	public AdminAccount(String username, String password, int id) {
		super(username, password, id);
		this.password = password;
		this.username = username;
	}

	public String getUsername() {
		return username;
	}

	public boolean verifyPassword(String pass) {
		return (pass.equals(this.password));
	}

	public String toString() {
		return this.username + " , " + getClass();
	}

}
