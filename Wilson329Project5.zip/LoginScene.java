// Elhanan Wilson

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.io.PrintWriter;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class LoginScene extends SceneBasic {

	private Scene scene; 
	private Label errorMessage = new Label(); 
	private UserInput userInput = new UserInput("Username:"); 
	private PasswordInput passInput = new PasswordInput("Password:");
	private ButtonBar bar = new ButtonBar(); 
	private CustomerChat chat = new CustomerChat(); 

	LoginScene() {
		super("Login Scene");

		Label message = new Label("Login Menu");
		message.setFont(new Font(50));

		bar.addButton("Login", e -> login()); 
		bar.addButton("Settings", e -> SceneManager.setScene(SceneManager.SceneType.settings)); 
		bar.addButton("Chat", e -> chat.start(new Stage())); 
		GridPane gridPane = new GridPane();
		gridPane.setMinSize(400, 200);
		gridPane.setPadding(new Insets(10, 10, 10, 10));
		gridPane.setVgap(5);
		gridPane.setHgap(5);
		gridPane.add(userInput, 0, 0);
		gridPane.add(passInput, 0, 1);
		gridPane.add(bar, 0, 2);
		errorMessage.setTextFill(Color.RED);
		gridPane.add(errorMessage, 1, 3);
		gridPane.setAlignment(Pos.TOP_CENTER);
		root.getChildren().addAll(gridPane);
	}

	public void login() { 
		if (SceneManager.getSocket() == null) {
			errorMessage.setText("Error Trying to connect to the Server");
		} else {
			try {

				PrintWriter outgoing = new PrintWriter(SceneManager.getSocket().getOutputStream()); 																								// the server
				outgoing.println("LOGIN");
				outgoing.println(userInput.getText());
				outgoing.println(passInput.getText());
				System.out.println(passInput.getText()+"LLL");
				outgoing.flush();
			}

			catch (IOException e) {
				e.printStackTrace();
			}

			try {

				BufferedReader incoming = new BufferedReader(
						new InputStreamReader(SceneManager.getSocket().getInputStream())); 
				String input = incoming.readLine();
				if (input.equals("ADMIN_SCENE")) {
					SceneManager.setScene(SceneManager.SceneType.admin);
					; 
				} else if (input.equals("CUSTOMER_SCENE")) { 
					SceneManager.setScene(SceneManager.SceneType.customer);
					; 
				} else if (input.equals("INVALID_USERNAME")) {
					errorMessage.setText("Invalid Username");
				} else if (input.equals("INVALID_PASSWORD")) {
					errorMessage.setText("Invalid Password"); 
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public Scene getScene() {
		errorMessage.setText("");
		return super.getScene();
	}

}
