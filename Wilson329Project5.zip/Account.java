// Elhanan Wilson

public abstract class Account {

	private String username;
	private String password;
	private int id;

	public Account(String user, String pass, int id) {
		this.username = user;
		this.password = pass;
		this.id = id;
	}
	
	public int getId() {
		return this.id;
	}

	public String getUsername() {
		return username;
	}

	public boolean verifyPassword(String pass) {
		return (pass.equals(this.password));
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String toString() {
		return this.username + " , " + getClass();
	}

	public String getPassword() {
		return password;
	}
}
