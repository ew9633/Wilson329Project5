// Elhanan Wilson

import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;

import java.net.Socket;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class ViewOrdersScene extends SceneBasic {
	private GridPane gridPane = new GridPane(); 
	private OutputTable output = new OutputTable("Stock #", "Description", "Quantity"); 

	public ViewOrdersScene() {
		super("Your Orders");
		root.getChildren().addAll(gridPane);
	}


	public void getOrders() {
		try {
			Socket connection = SceneManager.getSocket(); 
			PrintWriter outgoing; 
			outgoing = new PrintWriter(connection.getOutputStream());
			System.out.println("Sending... VIEW_ORDERS");
			outgoing.println("VIEW_ORDERS");
			outgoing.flush();

			BufferedReader incoming = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			System.out.println("Waiting for orders...");
			String stockNumber = incoming.readLine();

			gridPane = new GridPane();
			gridPane.setPadding(new Insets(10, 10, 10, 10));
			gridPane.setVgap(5);
			gridPane.setHgap(5);
			gridPane.setAlignment(Pos.CENTER);
			root.getChildren().set(1, gridPane);
			while (!stockNumber.equals("DONE")) {
				String description = incoming.readLine();
				String quantity = incoming.readLine();

				output.addRow(stockNumber, description, quantity);

				System.out.println("Received " + stockNumber + ", " + description); 
				stockNumber = incoming.readLine();
			}
			output.clearData(); 
			root.getChildren().addAll(output); 
			addButton("Return to Menu", e -> SceneManager.setScene(SceneManager.SceneType.customer)); 

		} catch (Exception e) {
			System.out.println("Error:  " + e);
		}
	}
}
