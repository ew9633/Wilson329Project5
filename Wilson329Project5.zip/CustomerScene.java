// Elhanan Wilson

import javafx.stage.Stage;

public class CustomerScene extends SceneBasic {
	
	CustomerChat chat = new CustomerChat(); 

	public CustomerScene() {
        super("Customer Menu");
        addButton("View Orders", e -> SceneManager.setScene(SceneManager.SceneType.viewOrders)); 
        addButton("Place Order", e -> SceneManager.setScene(SceneManager.SceneType.placeOrder)); 
        addButton("Show Profile", e -> SceneManager.setScene(SceneManager.SceneType.profile)); 
        addButton("Change Password", e -> SceneManager.setScene(SceneManager.SceneType.changePassword)); 
        addButton("Logout", e -> logout()); 
        addButton("Chat", e -> chat.start(new Stage())); 

	}
}
