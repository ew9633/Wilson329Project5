// Elhanan Wilson

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class AccountsReader {

	public static HashMap<String, Account> readFile(String filename) {
		HashMap<String, Account> accounts = new HashMap<String, Account>();

		Scanner data; 

		try {
			data = new Scanner(new File(filename));
		} catch (FileNotFoundException e) {
			System.out.println("Can't find file " + filename);
			return null; 
		}
		String check = data.nextLine();
		if (!(check.equals("<ACCOUNTS>"))) { 
			System.out.println("Not an account file:");
			return null;
		}
		while (data.hasNextLine()) {

			String accountType = data.nextLine(); 
			if (accountType.equals("<CUSTOMER>")) {
				CustomerAccount customer; 
				String temp = data.nextLine(); 
				String id = data.nextLine(); 
				temp = data.nextLine();
				temp = data.nextLine();
				String username = data.nextLine();
				temp = data.nextLine();
				temp = data.nextLine();
				String password = data.nextLine(); 
				temp = data.nextLine();
				temp = data.nextLine();
				String profile = data.nextLine(); 
				temp = data.nextLine();
				temp = data.nextLine();
				int idNum = Integer.parseInt(id);
				customer = new CustomerAccount(username, password, profile, idNum);
				accounts.put(id, customer);
			} else if (accountType.equals("<ADMINISTRATOR>")) {
				AdminAccount admin;
				String temp = data.nextLine(); 
				String id = data.nextLine();
				temp = data.nextLine();
				temp = data.nextLine();
				String username = data.nextLine(); 
				temp = data.nextLine();
				temp = data.nextLine();
				String password = data.nextLine(); 
				temp = data.nextLine();
				temp = data.nextLine();
				int idNum = Integer.parseInt(id);
				admin = new AdminAccount(username, password, idNum);
				accounts.put(id, admin);
			} else if (!(accountType.equals("</ACCOUNTS>"))) {
				System.out.println("Can not tell which account type:");
				System.out.println(accountType);
			}
		}

		return accounts;
	} 

}
