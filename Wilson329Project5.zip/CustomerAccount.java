// Elhanan Wilson

public class CustomerAccount extends Account {
	public String profile;

	public CustomerAccount(String username, String password, String profile, int id) {
		super(username, password, id);
		this.profile = profile;
	}

	public String getProfile() {
		return profile;
	}
}