// Elhanan Wilson

import java.io.IOException;
import java.io.PrintWriter;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public abstract class SceneBasic {
	private Scene scene; 
	private String title; 
	protected VBox root = new VBox(); 
	protected Button chatButton = new Button("Chat");

	public SceneBasic(String title) {
		Label message = new Label(title);
        message.setFont(new Font(40));
        root.getChildren().addAll(message);
        root.setAlignment(Pos.TOP_CENTER);
        scene = new Scene(root, 450, 250);
	}

	public Scene getScene() {
		return this.scene;
	}

	public void setScene(Scene scene) {
		this.scene = scene;
	}


	public void logout() {
		try {
			PrintWriter outgoing = new PrintWriter(SceneManager.getSocket().getOutputStream()); 
																								
			outgoing.println("QUIT");
			outgoing.flush();
			SceneManager.setScene(SceneManager.SceneType.login);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	
	public void addButton(String text, EventHandler<ActionEvent> func) {
		Button button = new Button(text);
		button.setMinWidth(200);
		button.setOnAction(func);
		root.getChildren().addAll(button);
		
	}

}
