// Elhanan Wilson

import java.net.Socket;
import java.util.HashMap;
import javafx.stage.Stage;
import javafx.scene.Scene;

public class SceneManager {
	public static enum SceneType {login, admin, customer, changePassword, accountList, profile, settings, placeOrder, viewOrders} 
	private static HashMap<SceneType, SceneBasic> scenes = new HashMap<SceneType, SceneBasic>(); 
    private static Socket connection; 
	private static Stage stage; 

	public SceneManager() {
		scenes.put(SceneType.login, new LoginScene());
		scenes.put(SceneType.admin, new AdminScene());
		scenes.put(SceneType.customer, new CustomerScene());
		scenes.put(SceneType.changePassword, new ChangePasswordScene());
		scenes.put(SceneType.accountList, new AccountListScene());
		scenes.put(SceneType.profile, new ProfileScene());
		scenes.put(SceneType.settings, new SettingsScene());
		scenes.put(SceneType.placeOrder, new PlaceOrderScene());
		scenes.put(SceneType.viewOrders, new ViewOrdersScene());
	}
	
	public static void setSocket(Socket setConnection) {
		connection = setConnection;
	}

	public static Socket getSocket() {
		return connection;
	}

	public void setStage(Stage stage) {
		this.stage = stage;
	}
	
	public static void setScene(SceneType type) {
		if (type == SceneType.accountList)
			((AccountListScene) scenes.get(type)).getAccountList(); 
		else if (type == SceneType.profile)
			((ProfileScene) scenes.get(type)).getProfile(); 
		else if (type == SceneType.placeOrder)
			((PlaceOrderScene) scenes.get(type)).getInventory(); 
		else if (type == SceneType.viewOrders)
			((ViewOrdersScene) scenes.get(type)).getOrders(); 
		stage.setScene(scenes.get(type).getScene()); 
	}
}
