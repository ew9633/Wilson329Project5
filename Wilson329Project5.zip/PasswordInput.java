// Elhanan Wilson

import javafx.scene.control.TextField;

public class PasswordInput extends UserInput {

	public PasswordInput(String text) {
		super(text);
		getChildren().remove(textField);
		TextField passField = new TextField(); 
		textField = passField;
		super.getChildren().addAll(passField);
	}

}
